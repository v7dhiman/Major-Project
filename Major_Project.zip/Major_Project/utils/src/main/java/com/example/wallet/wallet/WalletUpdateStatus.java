package com.example.wallet.wallet;

public enum WalletUpdateStatus {

    SUCCESS,
    FAILED
}
