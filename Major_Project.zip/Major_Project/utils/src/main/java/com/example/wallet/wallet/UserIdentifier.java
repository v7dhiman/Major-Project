package com.example.wallet.wallet;

public enum UserIdentifier {

    PAN,
    AADHAAR_CARD,
    SERVICE_ID
}
