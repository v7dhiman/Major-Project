package com.example.wallet.wallet;

public enum TransactionStatus {


    PENDING,
    SUCCESSFUL,
    FAILED
}
